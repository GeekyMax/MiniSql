create table good(id int, price float);
insert into good values(20,11.1);
show tables;
select * from good;